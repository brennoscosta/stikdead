import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { createMatch, stepMatch } from '../game/sim.js';
import { createBot, botDecide, DIFFICULTIES } from '../game/bot.js';
import { createInput } from '../game/input.js';
import { createRenderer } from '../game/renderer.js';
import '../battle.css';

const DIFF_LABEL = { facil: 'Fácil', medio: 'Médio', dificil: 'Difícil', insano: 'Insano' };

export default function Battle({ profile }) {
  const [screen, setScreen] = useState('select'); // select | fight
  const [difficulty, setDifficulty] = useState('medio');

  return screen === 'select' ? (
    <DifficultySelect
      onPick={(d) => {
        setDifficulty(d);
        setScreen('fight');
      }}
    />
  ) : (
    <Fight
      profile={profile}
      difficulty={difficulty}
      onExit={() => setScreen('select')}
    />
  );
}

function DifficultySelect({ onPick }) {
  const nav = useNavigate();
  return (
    <div className="scene">
      <h1 className="brand" style={{ fontSize: 'clamp(40px, 8vw, 60px)' }}>
        MODO <span className="red">TREINO</span>
      </h1>
      <div className="tagline">Escolha a dificuldade do bot</div>
      <div className="card">
        {Object.keys(DIFFICULTIES).map((d) => (
          <button
            key={d}
            className={`btn ${d === 'insano' ? 'btn-blood' : 'btn-ghost'}`}
            onClick={() => onPick(d)}
          >
            {DIFF_LABEL[d]}
          </button>
        ))}
        <button className="btn btn-ghost" style={{ marginTop: 24 }} onClick={() => nav('/perfil')}>
          Voltar ao perfil
        </button>
      </div>
    </div>
  );
}

function Fight({ profile, difficulty, onExit }) {
  const hostRef = useRef(null);
  const hud = {
    hpA: useRef(null), hpB: useRef(null),
    dotsA: useRef(null), dotsB: useRef(null),
    timer: useRef(null), announce: useRef(null),
    combo: useRef(null), center: useRef(null),
  };
  const inputRef = useRef(null);
  const pausedRef = useRef(false);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState(null);
  const [runId, setRunId] = useState(0);

  const setPause = useCallback((v) => {
    pausedRef.current = v;
    setPaused(v);
  }, []);

  useEffect(() => {
    let alive = true;
    let renderer = null;
    let raf = 0;
    const match = createMatch();
    const bot = createBot(difficulty);
    const input = createInput();
    inputRef.current = input;

    let announceT = 0;
    const announce = (text, cls = '') => {
      const el = hud.announce.current;
      if (!el) return;
      el.textContent = text;
      el.className = `bt-announce show ${cls}`;
      announceT = 1.2;
    };

    const centerText = (text) => {
      const el = hud.center.current;
      if (!el) return;
      el.textContent = text;
      el.classList.toggle('show', !!text);
    };

    (async () => {
      renderer = await createRenderer(hostRef.current);
      if (!alive) return renderer.destroy();

      let last = performance.now();
      let lastCount = null;

      const loop = (now) => {
        if (!alive) return;
        raf = requestAnimationFrame(loop);
        const dt = Math.min(0.033, (now - last) / 1000);
        last = now;

        let events = [];
        if (!pausedRef.current) {
          const inp = input.get();
          const botInp = botDecide(bot, match, 1, dt);
          events = stepMatch(match, inp, botInp, dt);
        }

        for (const e of events) {
          if (e.type === 'fightstart') { centerText('LUTE!'); setTimeout(() => centerText(''), 650); }
          if (e.type === 'firstblood') announce('PRIMEIRO SANGUE!');
          if (e.type === 'suddendeath') announce('MORTE SÚBITA!', 'red');
          if (e.type === 'ko') announce(e.finisher ? 'FINALIZAÇÃO!' : 'K.O.!', 'red');
          if (e.type === 'roundend' && match.phase !== 'matchend' && e.winner >= 0)
            setTimeout(() => announce(e.winner === 0 ? 'ROUND SEU!' : 'ROUND DO BOT!'), 700);
          if (e.type === 'matchend') setTimeout(() => setResult({ winner: e.winner, wins: [...match.wins] }), 1100);
        }

        // HUD
        const [a, b] = match.fighters;
        if (hud.hpA.current) hud.hpA.current.style.width = `${a.hp}%`;
        if (hud.hpB.current) hud.hpB.current.style.width = `${b.hp}%`;
        if (hud.timer.current)
          hud.timer.current.textContent = match.suddenDeath ? '!!' : String(Math.ceil(match.timer)).padStart(2, '0');
        if (hud.dotsA.current) hud.dotsA.current.dataset.wins = match.wins[0];
        if (hud.dotsB.current) hud.dotsB.current.dataset.wins = match.wins[1];

        const combo = a.combo >= 3 ? a.combo : 0;
        const comboEl = hud.combo.current;
        if (comboEl) {
          comboEl.classList.toggle('show', combo > 0);
          if (combo > 0) comboEl.innerHTML = `<b>${combo}</b> HITS${combo >= 8 ? '<i>COMBO INSANO!</i>' : ''}`;
        }

        if (match.phase === 'countdown') {
          const n = Math.ceil(3.4 - match.phaseT - 0.3);
          if (n >= 1 && n <= 3 && n !== lastCount) { centerText(String(n)); lastCount = n; }
        } else lastCount = null;

        if (announceT > 0) {
          announceT -= dt;
          if (announceT <= 0 && hud.announce.current) hud.announce.current.className = 'bt-announce';
        }

        renderer.frame(match, events, pausedRef.current ? 0 : dt);
      };
      raf = requestAnimationFrame(loop);
    })();

    const onKey = (e) => {
      if (e.code === 'Escape') setPause(!pausedRef.current);
    };
    window.addEventListener('keydown', onKey);

    const portrait = window.matchMedia('(orientation: portrait)');
    const coarse = window.matchMedia('(pointer: coarse)').matches;
    const onRotate = () => {
      if (coarse) setPause(portrait.matches);
    };
    portrait.addEventListener('change', onRotate);
    onRotate();

    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      window.removeEventListener('keydown', onKey);
      portrait.removeEventListener('change', onRotate);
      input.destroy();
      renderer?.destroy();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [difficulty, runId]);

  return (
    <div className="bt-root">
      <div className="bt-canvas" ref={hostRef} />

      <div className="bt-hud">
        <div className="bt-plate left">
          <div className="bt-name">{profile.fighter_name}</div>
          <div className="bt-bar"><div className="bt-fill" ref={hud.hpA} /></div>
          <div className="bt-dots" ref={hud.dotsA} data-wins="0"><i /><i /></div>
        </div>
        <div className="bt-timer" ref={hud.timer}>99</div>
        <div className="bt-plate right">
          <div className="bt-name">BOT · {DIFF_LABEL[difficulty]}</div>
          <div className="bt-bar"><div className="bt-fill" ref={hud.hpB} /></div>
          <div className="bt-dots" ref={hud.dotsB} data-wins="0"><i /><i /></div>
        </div>
      </div>

      <div className="bt-combo" ref={hud.combo} />
      <div className="bt-announce" ref={hud.announce} />
      <div className="bt-center" ref={hud.center} />

      <button className="bt-pausebtn" onClick={() => setPause(true)} aria-label="Pausar">II</button>

      <TouchControls inputRef={inputRef} />

      <div className="bt-rotate">
        <div className="bt-rotate-icon" aria-hidden="true" />
        <div>GIRE O CELULAR PARA LUTAR</div>
      </div>

      {paused && !result && (
        <div className="bt-overlay">
          <div className="bt-panel">
            <h2>PAUSADO</h2>
            <button className="btn btn-blood" onClick={() => setPause(false)}>Continuar</button>
            <button className="btn btn-ghost" onClick={onExit}>Sair da luta</button>
          </div>
        </div>
      )}

      {result && (
        <div className="bt-overlay">
          <div className="bt-panel">
            <h1 className={`bt-result ${result.winner === 0 ? 'win' : 'lose'}`}>
              {result.winner === 0 ? 'VITÓRIA' : 'DERROTA'}
            </h1>
            <div className="bt-score">
              {result.wins[0]} <span>VS</span> {result.wins[1]}
            </div>
            <button
              className="btn btn-blood"
              onClick={() => {
                setResult(null);
                setPause(false);
                setRunId((n) => n + 1);
              }}
            >
              Lutar novamente
            </button>
            <button className="btn btn-ghost" onClick={onExit}>Trocar dificuldade</button>
          </div>
        </div>
      )}
    </div>
  );
}

function TouchControls({ inputRef }) {
  const stickRef = useRef(null);
  const knobRef = useRef(null);

  const setTouch = (k, v) => {
    if (inputRef.current) inputRef.current.touch[k] = v;
  };

  useEffect(() => {
    const zone = stickRef.current;
    const knob = knobRef.current;
    if (!zone) return;
    let pid = null;

    const move = (e) => {
      const rect = zone.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const dx = e.clientX - cx;
      const dy = e.clientY - cy;
      const max = rect.width / 2 - 18;
      const len = Math.hypot(dx, dy) || 1;
      const k = Math.min(1, max / len);
      knob.style.transform = `translate(${dx * k}px, ${dy * k}px)`;
      setTouch('left', dx < -14);
      setTouch('right', dx > 14);
      setTouch('jump', dy < -26);
    };
    const downH = (e) => { pid = e.pointerId; zone.setPointerCapture(pid); move(e); };
    const moveH = (e) => { if (e.pointerId === pid) move(e); };
    const upH = (e) => {
      if (e.pointerId !== pid) return;
      pid = null;
      knob.style.transform = '';
      setTouch('left', false); setTouch('right', false); setTouch('jump', false);
    };
    zone.addEventListener('pointerdown', downH);
    zone.addEventListener('pointermove', moveH);
    zone.addEventListener('pointerup', upH);
    zone.addEventListener('pointercancel', upH);
    return () => {
      zone.removeEventListener('pointerdown', downH);
      zone.removeEventListener('pointermove', moveH);
      zone.removeEventListener('pointerup', upH);
      zone.removeEventListener('pointercancel', upH);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const Btn = ({ act, label, cls = '' }) => (
    <button
      className={`bt-btn ${cls}`}
      onPointerDown={(e) => { e.preventDefault(); setTouch(act, true); }}
      onPointerUp={() => setTouch(act, false)}
      onPointerLeave={() => setTouch(act, false)}
      onContextMenu={(e) => e.preventDefault()}
    >
      {label}
    </button>
  );

  return (
    <div className="bt-touch">
      <div className="bt-stick" ref={stickRef}>
        <div className="bt-knob" ref={knobRef} />
      </div>
      <div className="bt-actions">
        <Btn act="dash" label="DASH" cls="sm" />
        <Btn act="block" label="BLOCK" cls="sm blue" />
        <Btn act="jump" label="JUMP" cls="sm green" />
        <Btn act="light" label="SOCO" cls="gold" />
        <Btn act="heavy" label="PESADO" cls="red" />
      </div>
    </div>
  );
}
